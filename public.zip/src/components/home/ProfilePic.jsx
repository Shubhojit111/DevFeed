import React from 'react'

const ProfilePic = () => {
  return (
     <div className="storyprofile h-full w-full   ">

        <img src="profile.jpg" alt="profile pic" />
      </div>
  )
}

export default ProfilePic

import React from 'react'
import Person from '../../components/home/Person'
import { UserPlus2 } from 'lucide-react'

const Interests = () => {
  return (
    <div className="interests h-fit w-full px-4 py-4 border border-[#1F2933] rounded-xl text-white bg-[#13191F]">

      <div className="text-[18px] font-bold  flex gap-2.5">
        <div className="text-sky-500">
            <UserPlus2 />
        </div>
        <h1 className=''>Who to follow</h1>
      </div>

      <div className="people my-2">
        <div className="p1"><Person /></div>
        <div className="p1"><Person /></div>
        <div className="p1"><Person /></div>
        <div className="p1"><Person /></div>
        
      </div>

      <div className="h4 text-md font-semibold text-sky-500">See More</div>

    </div>



  )
}

export default Interests

import React from 'react'
import Person from '../../components/home/Person'
import Interest from './Interests'

const Right = () => {
  return (
    <div className="">

      <Interest />

    </div>



  )
}

export default Right
